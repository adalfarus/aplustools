import aplustools as apt

apt.updater.gitupdater.get_temp()
